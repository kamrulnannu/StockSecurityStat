#ifndef TRADE_STAT_H_INCLUDED
#define TRADE_STAT_H_INCLUDED

#include <bits/stdc++.h>
#include "StockInfo.h"

using namespace std;

class TradeStat
{
    private:
        struct SymbolStat
        {
            long long int m_TimeOfLastEntry = 0; // Last time a security is seen in input file
            long long int m_TotalVolume = 0;  // Sum of qty of a given symbol
            int m_MaxPrice = 0;
            long long int m_MaxGap = 0;
            long long int m_Weight; // price1 * qty1 + price2 * qty2 + ...

            SymbolStat()
            {}

            explicit SymbolStat(const long long int time, const int volume, const int price) :
                m_TimeOfLastEntry(time),
                m_TotalVolume(volume),
                m_MaxPrice(price),
                m_MaxGap(0),
                m_Weight(volume * price)
            {
            }

            int GetWeightedAvgPrc() const
            {
                return (m_Weight / m_TotalVolume);
            }

            string GetOutputString(const string & sym) const
            {
                /*
                 * <Symbol>,<MaxTimeGap>,<TotalVolume>,<WeightedAvgPrice>,<MaxPrice>
                 */
                string s = sym + "," 
                    + std::to_string(m_MaxGap) + "," 
                    + std::to_string(m_TotalVolume) + "," 
                    + std::to_string(GetWeightedAvgPrc()) + ","
                    + std::to_string(m_MaxPrice);

                return s;
            }
        };

        map<string, SymbolStat> m_Sym2Stat;

    public:
        void UpdateSymbolStat(const StockInfo &si);

        void WriteStatToOutFile(const char * outfile);
};
#endif
