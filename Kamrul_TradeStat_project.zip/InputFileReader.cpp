#include "InputFileReader.h"
//#include <boost/algorithm/string.hpp>

void InputFileReader::OpenFileForRead()
{
    m_FileDescriptor.open(m_FileName.c_str(), ios::in);

    if (!m_FileDescriptor)
    {
        cerr <<"ERROR: OpenFileForRead - Can not open input file for read, fn=" 
             << m_FileName << endl;
        exit(1);
    }
}

vector<string> InputFileReader::Tokenize(const string & aLine, char delim)
{
    istringstream tokStream(aLine);
    vector<string> tokList;
    string tok;

    while (std::getline(tokStream, tok, delim))
    {
        tokList.push_back(tok);
    }
    return tokList;
}

std::optional<StockInfo> InputFileReader::ReadNextLine()
{
    if (!m_FileDescriptor.is_open())
    {
        cerr<<"ERROR: ReadNextLine - Input is not open, fn = "<<m_FileName << endl;
        exit(2);
    }

    if (IsEOF())
    {
        cerr << "WARN: ReadNextLine - End of file"<<endl;
        return nullopt;  // Indicator of end of file
    }

    std::string aLine;

    m_LineNumber++;

    /*
     * Expected Input line:
     * <TimeStamp>,<Symbol>,<Share/Volume>,<Price>
     */
    if (std::getline(m_FileDescriptor, aLine))
    {
        vector<std::string> words = Tokenize(aLine, m_Delimeter[0]);
        
        //boost::algorithm::split(words, aLine, boost::is_any_of(m_Delimeter));

        if (std::size(words) != m_NUM_ITEM_IN_A_LINE)
        {
            cerr<<"WARN: ReadNextLine - Invalid input line = "<< aLine <<endl;

            return { }; // indicator of invalid input line of getline error  
        }
        
        // cout << si << endl;  // For debugging

        try
        {
            StockInfo si(words);
            return si;
        }
        catch (const BadInputException & e)
        {
            /*
             * Bad input will not be processed. Comutaion will be wrtitten to
             * out file good inputs.
             */
            cerr<<"ERROR: " << e.what() <<", Input Line ="<< aLine
                <<", Line Num=" << m_LineNumber << endl;
        }
        return { }; // Indicator of Invalid input
    }
    else
    {
        if (!IsEOF())
        {
            cerr<<"WARN: ReadNextLine - getline failed."
                <<" Line Num="<< m_LineNumber << endl;
        }
        return { }; // Indicator of invalid input line or eof or getline error
    }
}
