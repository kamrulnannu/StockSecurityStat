#include "TradeStat.h"

void TradeStat::UpdateSymbolStat(const StockInfo & si)
{
    auto itr = m_Sym2Stat.find(si.m_Symbol);

    if (itr == m_Sym2Stat.end())
    {
        // This symbol is seen 1st time
        SymbolStat ss (si.m_TimeStamp, si.m_Share, si.m_Price);

        m_Sym2Stat[si.m_Symbol] = ss;
    }
    else
    {
        // This symbol is seen before
        itr->second.m_TotalVolume += si.m_Share;
        itr->second.m_Weight += (si.m_Share * si.m_Price);

        if (si.m_Price > itr->second.m_MaxPrice)
        {
            itr->second.m_MaxPrice = si.m_Price;
        }

        itr->second.m_MaxGap = std::max(itr->second.m_MaxGap, 
                               si.m_TimeStamp - itr->second.m_TimeOfLastEntry);

        itr->second.m_TimeOfLastEntry = si.m_TimeStamp;
    }
}

void TradeStat::WriteStatToOutFile(const char *outfile)
{
    if (!outfile)
    {
        cerr<<"ERROR: WriteStatToOutFile - NULL out file"<<endl;
        return;
    }

    fstream outFd;

    outFd.open(outfile, ios::out);

    if (!outFd)
    {
        cerr <<"ERROR: WriteStatToOutFile - could not open file to write, fn="
             << outfile << endl;
        exit(3);
    }

    auto itr = m_Sym2Stat.begin();

    while (itr != m_Sym2Stat.end())
    {
        string out_line = itr->second.GetOutputString(itr->first);

        outFd << out_line << endl;

        itr++;
    }

    outFd.close();
}
