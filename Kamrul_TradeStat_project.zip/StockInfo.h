#ifndef STOCK_INFO_H_INCLUDED
#define STOCK_INFO_H_INCLUDED

#include <bits/stdc++.h>

using namespace std;

static std::mutex mtx;
static long long int gs_LasTimeStamp = 0; // Time stamp from previous input line

struct BadInputException : public exception
{
    private:
        const string m_ExceptionMsg;

    public:
        BadInputException(const string & msg) : m_ExceptionMsg(msg)
        {}

       const char * what () const noexcept
       {
            return m_ExceptionMsg.c_str();
       } 
};

class StockInfo
{
    /*
     * This class will have info of a line from input file
     */

    private:
        bool IsValidInputStream(string &out_msg) const
        {
            if (m_TimeStamp <= 0)
            {
                out_msg = "Time stamp value <= 0!";
                return false;
            }
            else if (m_Symbol.length() == 0)
            {
                out_msg = "Invalid symbol!";
                return false;
            }
            else if (m_Share <= 0)
            {
                out_msg = "Share value <= 0!";
                return false;
            }
            else if (m_Price <= 0)
            {
                out_msg = "Share price is <= 0!";
                return false;
            }
            else if (m_TimeStamp < gs_LasTimeStamp)
            {
                out_msg = "Current time stamp is less than previous time stamp!";
                return false;
            }

            out_msg = "";

            return true;
        }

    public:
        long long int m_TimeStamp = 0;
        string m_Symbol ="";
        int m_Share = 0;
        int m_Price = 0;


        StockInfo() = default;

        StockInfo(const string & sym, const int price, const int share, const long long int ts) :
            m_TimeStamp(ts),
            m_Symbol(sym),
            m_Share(share),
            m_Price(price)
        {
            lock_guard<std::mutex> lck(mtx);
            string out_msg;
            if (!IsValidInputStream(out_msg))
            {
                throw BadInputException(out_msg);
            }

            gs_LasTimeStamp = ts;
        }


        StockInfo(const vector<std::string> & data) :
            m_TimeStamp(std::stoll(data[0])),
            m_Symbol(data[1]),
            m_Share(std::stoi(data[2])),
            m_Price(std::stoi(data[3]))
        {
            lock_guard<std::mutex> lck(mtx);
            string out_msg;
            if (!IsValidInputStream(out_msg))
            {
                throw BadInputException(out_msg);
            }
            gs_LasTimeStamp = m_TimeStamp;
        }

        StockInfo(const StockInfo &rhs) = default;

        StockInfo & operator = (const StockInfo & rhs) = default;

        void SetStockInfo(const string & sym, const int price, 
                          const int share, const long long int ts) 
        {
            m_Symbol = sym;
            m_Price = price;
            m_Share = share;
            m_TimeStamp = ts;

            lock_guard<std::mutex> lck(mtx);
            string out_msg;
            if (!IsValidInputStream(out_msg))
            {
                throw BadInputException(out_msg);
            }
            gs_LasTimeStamp = ts;
        } 

        /*
         * For debugging
         */
        friend ostream & operator << (ostream & out, const StockInfo & si)
        {
            out << si.m_TimeStamp <<","
                << si.m_Symbol << ","
                << si.m_Share  << ","
                << si.m_Price;

            return out;
        }
};

#endif
